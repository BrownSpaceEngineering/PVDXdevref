
/*
 * Auto generated Run-Time-Environment Configuration File
 *      *** Do not modify ! ***
 *
 * Project: 'SCH1600' 
 * Target:  'STM32F401' 
 */

#ifndef PRE_INCLUDE_GLOBAL_H
#define PRE_INCLUDE_GLOBAL_H

/* Keil::Device:STM32Cube HAL:Common@1.8.1 */
#define USE_HAL_DRIVER


#endif /* PRE_INCLUDE_GLOBAL_H */
